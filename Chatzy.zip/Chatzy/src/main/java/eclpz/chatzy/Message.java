package eclpz.chatzy;

/**
 * Class representing a chat message payload and tracking flags.
 */
public class Message {
    private String messagePayload;
    private String recipientPhoneNumber;
    private boolean messageSent;
    private boolean messageReceived;
    private boolean messageRead;

    public Message(String messagePayload, String recipientPhoneNumber) {
        this.messagePayload = messagePayload;
        this.recipientPhoneNumber = recipientPhoneNumber;
        this.messageSent = false;
        this.messageReceived = false;
        this.messageRead = false;
    }

    public String getMessagePayload() { return messagePayload; }
    public void setMessagePayload(String messagePayload) { this.messagePayload = messagePayload; }

    public String getRecipientPhoneNumber() { return recipientPhoneNumber; }
    public void setRecipientPhoneNumber(String recipientPhoneNumber) { this.recipientPhoneNumber = recipientPhoneNumber; }

    public boolean isMessageSent() { return messageSent; }
    public void setMessageSent(boolean messageSent) { this.messageSent = messageSent; }

    public boolean isMessageReceived() { return messageReceived; }
    public void setMessageReceived(boolean messageReceived) { this.messageReceived = messageReceived; }

    public boolean isMessageRead() { return messageRead; }
    public void setMessageRead(boolean messageRead) { this.messageRead = messageRead; }
}
