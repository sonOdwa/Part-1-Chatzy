package eclpz.chatzy;

import java.util.Scanner;

/**
 * Main application driver for the Chat Application Portfolio of Evidence (PoE).
 */
public class Main {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("=== Chat Application Registration ===");
            System.out.print("Enter First Name: ");
            String firstName = scanner.nextLine();
            System.out.print("Enter Last Name: ");
            String lastName = scanner.nextLine();
            
            Login login = new Login(firstName, lastName);
            
            // Registration Loop
            boolean registered = false;
            while (!registered) {
                System.out.print("Enter Username (must contain '_' and <= 5 chars): ");
                String username = scanner.nextLine();
                
                System.out.print("Enter Password (>= 8 chars, 1 uppercase, 1 digit, 1 special char): ");
                String password = scanner.nextLine();
                
                System.out.print("Enter Cell Phone Number (with international code, <= 10 chars): ");
                String cellNumber = scanner.nextLine();
                
                String regResult = login.registerUser(username, password, cellNumber);
                System.out.println(regResult);
                
                if (regResult.contains("successfully captured")) {
                    registered = true;
                } else {
                    System.out.println("Please try registration again.\n");
                }
            }
            
            // Login Loop
            System.out.println("\n=== Chat Application Login ===");
            boolean loggedIn = false;
            while (!loggedIn) {
                System.out.print("Enter Username: ");
                String loginUser = scanner.nextLine();
                
                System.out.print("Enter Password: ");
                String loginPass = scanner.nextLine();
                
                boolean success = login.loginUser(loginUser, loginPass);
                String loginMessage = login.returnLoginStatus(success);
                System.out.println(loginMessage);
                
                if (success) {
                    loggedIn = true;
                }
            }
            
            // Chat Feature Demo
            System.out.println("\n=== Send a Message ===");
            System.out.print("Enter Recipient Cell Phone Number: ");
            String recipient = scanner.nextLine();
            System.out.print("Enter Message Text: ");
            String payload = scanner.nextLine();
            
            Message msg = new Message(payload, recipient);
            msg.setMessageSent(true);
            msg.setMessageReceived(true);
            msg.setMessageRead(true);
            
            System.out.println("\n--- Message Status ---");
            System.out.println("Recipient: " + msg.getRecipientPhoneNumber());
            System.out.println("Payload: " + msg.getMessagePayload());
            System.out.println("Sent: " + msg.isMessageSent());
            System.out.println("Received: " + msg.isMessageReceived());
            System.out.println("Read: " + msg.isMessageRead());
        }
    }
}
