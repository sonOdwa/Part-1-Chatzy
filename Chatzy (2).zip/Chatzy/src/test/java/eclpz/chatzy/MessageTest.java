package eclpz.chatzy;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * JUnit unit tests for Part 2 Message class functions based on assessment rubric specifications.
 */
public class MessageTest {

    private Message message1;
    private Message message2;

    public void setUp() {
        // Test Data for Task 1 & Task 2 from rubric
        message1 = new Message("0012345678", 0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        message2 = new Message("0098765432", 1, "08575975889", "Hi Keegan, did you receive the payment?");
    }

    // -------------------------------------------------------------
    // Test AssertEquals: Message Length Validation
    // -------------------------------------------------------------

    
    public void testMessageLengthSuccess() {
        String testPayload = "Hi Mike, can you join us for dinner tonight?";
        String actual = Message.checkMessageLength(testPayload);
        assertEquals("Message ready to send.", actual);
    }

    
    public void testMessageLengthFailure() {
        // Create a string of 260 characters (exceeds 250 by 10)
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 260; i++) {
            sb.append("A");
        }
        String actual = Message.checkMessageLength(sb.toString());
        assertEquals("Message exceeds 250 characters by 10; please reduce the size.", actual);
    }

    // -------------------------------------------------------------
    // Test AssertEquals: Recipient Cell Formatting
    // -------------------------------------------------------------

    
    public void testRecipientCellSuccess() {
        String recipient = "+27718693002";
        String actual = Message.checkRecipientCell(recipient);
        assertEquals("Cell phone number successfully captured.", actual);
    }

    
    public void testRecipientCellFailure() {
        String recipient = "08575975889";
        String actual = Message.checkRecipientCell(recipient);
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.", actual);
    }

    // -------------------------------------------------------------
    // Test AssertEquals: Message Hash Creation
    // -------------------------------------------------------------

    
    public void testMessageHashCreation() {
        String hash = Message.createMessageHash("0012345678", 0, "Hi Mike, can you join us for dinner tonight?");
        assertEquals("00:0:HITONIGHT", hash);
    }

    // -------------------------------------------------------------
    // Test AssertEquals: Message ID Validation
    // -------------------------------------------------------------

    
    public void testCheckMessageID() {
        assertTrue(message1.checkMessageID());
    }

    // -------------------------------------------------------------
    // Test AssertEquals: SentMessage Options
    // -------------------------------------------------------------

    
    public void testSentMessageOption1_Send() {
        String result = message1.SentMessage(1);
        assertEquals("Message successfully sent.", result);
    }

    
    public void testSentMessageOption2_Disregard() {
        String result = message2.SentMessage(2);
        assertEquals("Press 0 to delete the message.", result);
    }

    
    public void testSentMessageOption3_Store() {
        Message testMsg = new Message(2, "+27831234567", "Test store message");
        String result = testMsg.SentMessage(3);
        assertEquals("Message successfully stored.", result);
    }
}
