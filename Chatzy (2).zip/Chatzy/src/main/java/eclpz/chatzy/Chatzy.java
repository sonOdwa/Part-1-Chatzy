/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package eclpz.chatzy;

/**
 *
 * @author Student
 */
public class Chatzy {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
